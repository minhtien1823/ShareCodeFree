
package String;



public class TestMyString {
    public static void main(String[] args) {
        MyString.main(null);
    }
}

