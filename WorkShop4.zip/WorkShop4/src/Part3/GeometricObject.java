
package Part3;

/**
 *
 * @author mac
 */
public interface GeometricObject {
    
    public double getPerimeter();
    public double getArea();

    public void resize(int i);

}