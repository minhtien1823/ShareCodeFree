
package Point.java;


public class TestPoint2D {

    
    public static void main(String[] args) {
          
    Point2D p1 = new Point2D();
    System.out.println("Point 1: x = " + p1.getX() + ", y = " + p1.getY());

   
    Point2D p2 = new Point2D(3.14f, 1.414);
    System.out.println("Point 2: x = " + p2.getX() + ", y = " + p2.getY());
  }
 }
    

